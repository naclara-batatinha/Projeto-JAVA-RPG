
package com.mycompany.rpg;
import java.util.Random;
import java.util.Scanner;

public class Rpg {
    
 public static void main(String[] args) {
    Player jogador = new Player();
    Enemy adversario1 = new Enemy();
    Enemy adversario2 = new Enemy();
    Enemy adversario3 = new Enemy();
    Enemy adversario4 = new Enemy();
    Enemy adversario5 = new Enemy();
    Enemy adversario6 = new Enemy();
    
     Scanner ler = new Scanner(System.in);
     Random gerador = new Random();
     
     Weapon armaDoJogador = new Weapon();
        //Armas iniciais
        Weapon arma1 = new Weapon();
        Weapon arma2 = new Weapon();
        Weapon arma3 = new Weapon();
        //Armas avançadas
        Weapon arma4 = new Weapon();
        Weapon arma5 = new Weapon();
        Weapon arma6 = new Weapon();
        
        Armor armaduraDoJogador = new Armor();
        //Armaduras iniciais
        Armor armadura1 = new Armor();
        Armor armadura2 = new Armor();
        Armor armadura3 = new Armor();
        //Armaduras avançadas
        Armor armadura4 = new Armor();
        Armor armadura5 = new Armor();
        Armor armadura6 = new Armor();
        
             //Set das Armas
        
        arma1.setNomeDaArma("Broken Straight Sword (Leve)");
        arma1.setCategoriaDaArma(1);
        arma1.setConstanteDeDano(1);
        
        arma2.setNomeDaArma("Broadsword (Leve)");
        arma2.setCategoriaDaArma(1);
        arma2.setConstanteDeDano(7);
        
        arma3.setNomeDaArma("Claymore (Pesada)");
        arma3.setCategoriaDaArma(2);
        arma3.setConstanteDeDano(5);
        
        arma4.setNomeDaArma("Greatsword (Pesada)");
        arma4.setCategoriaDaArma(2);
        arma4.setConstanteDeDano(10);
        
        arma5.setNomeDaArma("Moonlight Greatsword (Pesada)");
        arma5.setCategoriaDaArma(2);
        arma5.setConstanteDeDano(12);
        
        arma6.setNomeDaArma("Uchigatana (Leve)");
        arma6.setCategoriaDaArma(1);
        arma6.setConstanteDeDano(18);
     
               // set dos Inimigos
        
        adversario1.setNomeDoAdversario("Asylum Demon");
        adversario1.setPontosDeVidaDoAdversario(20);
        adversario1.setVidaMaximaDoAdversario(adversario1.getPontosDeVidaDoAdversario());
        adversario1.setDanoDoAdversario(12);
        adversario1.setDefesaDoAdversario(18);
        adversario1.setAgilidadeDoAdversario(1.5);
        
        adversario2.setNomeDoAdversario("Bell Gargoyle");
        adversario2.setPontosDeVidaDoAdversario(15);
        adversario2.setVidaMaximaDoAdversario(adversario2.getPontosDeVidaDoAdversario());
        adversario2.setDanoDoAdversario(14);
        adversario2.setDefesaDoAdversario(12);
        adversario2.setAgilidadeDoAdversario(9.5);
        
        adversario3.setNomeDoAdversario("Great Grey Wolf Sif");
        adversario3.setPontosDeVidaDoAdversario(12);
        adversario3.setVidaMaximaDoAdversario(adversario3.getPontosDeVidaDoAdversario());
        adversario3.setDanoDoAdversario(10);
        adversario3.setDefesaDoAdversario(14);
        adversario3.setAgilidadeDoAdversario(6.5);
        
        adversario4.setNomeDoAdversario("Ornstein and Smough");
        adversario4.setPontosDeVidaDoAdversario(42);
        adversario4.setVidaMaximaDoAdversario(adversario4.getPontosDeVidaDoAdversario());
        adversario4.setDanoDoAdversario(20);
        adversario4.setDefesaDoAdversario(20);
        adversario4.setAgilidadeDoAdversario(3.5);
        
        adversario5.setNomeDoAdversario("Artorias The Abysswalker");
        adversario5.setPontosDeVidaDoAdversario(40);
        adversario5.setVidaMaximaDoAdversario(adversario5.getPontosDeVidaDoAdversario());
        adversario5.setDanoDoAdversario(23);
        adversario5.setDefesaDoAdversario(18);
        adversario5.setAgilidadeDoAdversario(3.5);
        
        adversario6.setNomeDoAdversario("Gwyn Lord of Cinder");
        adversario6.setPontosDeVidaDoAdversario(100);
        adversario6.setVidaMaximaDoAdversario(adversario6.getPontosDeVidaDoAdversario());
        adversario6.setDanoDoAdversario(50);
        adversario6.setDefesaDoAdversario(20);
        adversario6.setAgilidadeDoAdversario(3.5);
        
                // Set das Armaduras 
                
        armadura1.setNomeDaArmadura("Sem Armadura");
        armadura1.setConstanteDeDefesa(0);
        
        armadura2.setNomeDaArmadura("Hunter Set");
        armadura2.setConstanteDeDefesa(2);
        
        armadura3.setNomeDaArmadura("Elite Knight Set");
        armadura3.setConstanteDeDefesa(3);
        
        armadura4.setNomeDaArmadura("Catarina Set");
        armadura4.setConstanteDeDefesa(5);
        
        armadura5.setNomeDaArmadura("Ornstein's Set");
        armadura5.setConstanteDeDefesa(10);
        
        armadura6.setNomeDaArmadura("Berserk Set");
        armadura6.setConstanteDeDefesa(18);        
     
     
        int escolha;
        String playerName;
        int vida = 0;
        int DadoDeVida = 0;
        int adversarioSelecionado = 0;
        int vitoria = 0;
        int confirmacao = 0;
        
        System.out.printf("\n\n\n\n\n\n");
	System.out.printf("         ##### ##                              /                 #######                             ###                \n");
	System.out.printf("      /#####  /##                            #/                /       ###                            ###               \n");
	System.out.printf("    //    /  / ###                           ##               /         ##                             ##               \n");
	System.out.printf("   /     /  /   ###                          ##               ##        #                              ##               \n");
	System.out.printf("        /  /     ###                         ##                ###                                     ##               \n");
	System.out.printf("       ## ##      ##    /###    ###  /###    ##  /##          ## ###           /###    ##    ###       ##       /###    \n");
	System.out.printf("       ## ##      ##   / ###  /  ###/ #### / ## / ###          ### ###        / ###  /  ##    ###  /   ##      / #### / \n");
	System.out.printf("       ## ##      ##  /   ###/    ##   ###/  ##/   /             ### ###     /   ###/   ##     ###/    ##     ##  ###/  \n");
	System.out.printf("       ## ##      ## ##    ##     ##         ##   /                ### /##  ##    ##    ##      ##     ##    ####       \n");
	System.out.printf("       ## ##      ## ##    ##     ##         ##  /                   #/ /## ##    ##    ##      ##     ##      ###      \n");
	System.out.printf("       #  ##      ## ##    ##     ##         ## ##                    #/ ## ##    ##    ##      ##     ##        ###    \n");
	System.out.printf("          /       /  ##    ##     ##         ######                    # /  ##    ##    ##      ##     ##          ###  \n");
	System.out.printf("     /###/       /   ##    /#     ##         ##  ###         /##        /   ##    ##    ##      /#     ##     /###  ##  \n");
	System.out.printf("    /   ########/     ####/ ##    ###        ##   ### /     /  ########/     ######      ######/ ##    ### / / #### /   \n");
	System.out.printf("   /       ####        ###   ##    ###        ##   ##/     /     #####        ####        #####   ##    ##/     ###/    \n");
	System.out.printf("   #                                                       |                                                            \n");
        while(true)
        {
            System.out.println("1- Comecar");
            System.out.println("2- Historia");
            System.out.println("3- Sair");
            escolha = ler.nextInt();
            
           switch (escolha){
                   
                   case (1): 
                        System.out.println("\nInsira seu nome: ");
                        playerName = ler.next();
                        jogador.setNomeDoJogador(playerName);
                        System.out.println("Bem vindo, " + jogador.getNomeDoJogador() + "\n");
                    for(int i = 0; i < 3; i++) 
                {
                    DadoDeVida = gerador.nextInt(6) + 1;
                    System.out.printf("%d° rolagem de vida: %d\n", i + 1, DadoDeVida);
                    vida += DadoDeVida;
                }
                      System.out.println("Total: " + vida);
                      levelUp(jogador,15, vida);
                      
                      escolhaDeArma(armaDoJogador, arma1, arma2, arma3);
                
                escolhaDeArmadura(armaduraDoJogador, armadura1, armadura2, armadura3, jogador);
                
                 if(adversarioSelecionado == 0)
                {
                    vitoria = combate(adversario1, jogador, armaDoJogador, armaduraDoJogador);
                }
                else if(adversarioSelecionado == 1)
                {
                    vitoria = combate(adversario2, jogador, armaDoJogador, armaduraDoJogador);
                }
                else if(adversarioSelecionado == 2)
                {
                    vitoria = combate(adversario3, jogador, armaDoJogador, armaduraDoJogador);
                }
                 if(vitoria == 1)
                {
                    System.out.println("Level Up!!!");
                    levelUp(jogador, 5, jogador.getVidaMaximaDoJogador());
                    
                    escolhaDeArmadura(armaduraDoJogador, armadura4, armadura5, armadura6, jogador);
                    
                    armaduraDoJogador.setValorDeArmadura(armaduraDoJogador.getConstanteDeDefesa() + (int) (1.5 * jogador.getConstituicaoDoJogador()));
                    
                    adversarioSelecionado = gerador.nextInt(2);
                    
                    if(adversarioSelecionado == 0)
                    {
                        vitoria = combate(adversario4, jogador, armaDoJogador, armaduraDoJogador);
                    }
                    else if(adversarioSelecionado == 1)
                    {
                        vitoria = combate(adversario5, jogador, armaDoJogador, armaduraDoJogador);
                    }
                }
                 
                 if(vitoria == 1)
                    {
                        System.out.println("Level Up!!!");
                        levelUp(jogador, 10, jogador.getVidaMaximaDoJogador());
                        
                        escolhaDeArma(armaDoJogador, arma4, arma5, arma6);
                        
                        armaduraDoJogador.setValorDeArmadura(armaduraDoJogador.getConstanteDeDefesa() + (int) (1.5 * jogador.getConstituicaoDoJogador()));
                        
                        vitoria = combate(adversario6, jogador, armaDoJogador, armaduraDoJogador);
                        
                        if(vitoria == 1)
                        {
                            victory();
                            System.out.println("\nApos eras, Kalameet foi finalmente derrotado!\n");
                            System.out.println("Seu olhar feroz que assustava todos que ousavam o desafiar nao surtiu efeito no corajoso heroi!\n");
                            System.out.println("Aquele que trouxe paz ao mundo...\n");
                            System.out.println("VIVA AO MAIOR HEROI DE TODOS OS TEMPOS: " + jogador.getNomeDoJogador() + "!!!\n");
                            break;
                        }
                  
                    }
                 else
                        {
                            gameOver();
                            break;
                        } 
                 
                    case  (2):
                       
                        String[] linhas = {
            "Na era dos antigos, o mundo estava deformado, coberto por nevoeiro. Uma terra de rochedos cinzentos, árvores antigas, e dragões eternos. Mas depois veio o fogo. E com o fogo veio a disparidade. Calor e frio, vida e morte, e claro... Luz e escuridão.",
            "Depois, da escuridão, eles vieram, e encontraram as almas (souls) dos Senhores dentro da chama.",
            "Nito, o primeiro dos mortos. A Bruxa de Izalith, e as suas filhas do Caos, Gwyn o senhor da Luz do Sol, e os seus fiéis cavaleiros. E os furtivos pigmeus, tão facilmente esquecidos.",
            "Com a força dos Senhores, eles desafiaram os dragões.",
            "Os poderosos raios de Gwyn arrancaram as suas escamas. As bruxas teceram grandes tempestades de fogo. Nito libertou um miasma de morte e doença.",
            "E Seath the Scaleless traiu os seus, e os dragões não existiam mais. Assim começou a era do fogo... Mas brevemente, as chamas irão esvanecer, e apenas a escuridão ficará. Mesmo agora, são apenas brasas, e o homem já não vê luz, mas apenas noites sem fim.",
            "E entre os vivos são vistos, portadores do amaldiçoado Darksign."
        };

        for (String linha : linhas) {
            System.out.println(linha);
        }    
                       
                   case (3): 
                     
                        System.out.println("\nSaindo...\n");
                break;
            
                            }

   
        }
                                          }
 
 
  public static void levelUp(Player jogador, int pontos, int vida)
    {
        Scanner ler = new Scanner(System.in);
        int totalDePontos = pontos;
        int pontoDestribuidoParaUmAtributo;
        
        System.out.println("\nDestribua pontos de atributo\n");
        
        while(true)
        {
            System.out.printf("Pontos Disponiveis: %d\n", totalDePontos);
            System.out.printf("Forca: ");
         
            pontoDestribuidoParaUmAtributo = ler.nextInt();
            
            if(pontoDestribuidoParaUmAtributo <= totalDePontos && pontoDestribuidoParaUmAtributo >= 0)
            {
                jogador.setForcaDoJogador(pontoDestribuidoParaUmAtributo + jogador.getForcaDoJogador());
                break;
            }
        }
         totalDePontos -= pontoDestribuidoParaUmAtributo;  

        if(totalDePontos > 0)
        {
            while(true)
            {
                System.out.printf("Pontos Disponiveis: %d\n", totalDePontos);
                System.out.printf("Constituicao: ");

                pontoDestribuidoParaUmAtributo = ler.nextInt();
                
                if(pontoDestribuidoParaUmAtributo <= totalDePontos && pontoDestribuidoParaUmAtributo >= 0)
                {
                    jogador.setConstituicaoDoJogador(pontoDestribuidoParaUmAtributo + jogador.getConstituicaoDoJogador());
                    break;
                }
            }
                  
            totalDePontos -= pontoDestribuidoParaUmAtributo;
        }
        if(totalDePontos > 0)
        {
            
            while(true)
            {
                System.out.printf("Pontos Disponiveis: %d\n", totalDePontos);
                System.out.printf("Agilidade: ");

                pontoDestribuidoParaUmAtributo = ler.nextInt();
                if(pontoDestribuidoParaUmAtributo <= totalDePontos && pontoDestribuidoParaUmAtributo >= 0)
                {
                    jogador.setAgilidadeDoJogador(pontoDestribuidoParaUmAtributo + jogador.getAgilidadeDoJogador());
                    break;
                }
            }

            totalDePontos -= pontoDestribuidoParaUmAtributo;
        }
        if(totalDePontos > 0)
        {
            while(true)
            {
                System.out.printf("Pontos Disponiveis: %d\n", totalDePontos);
                System.out.printf("Destreza: ");

                pontoDestribuidoParaUmAtributo = ler.nextInt();
                if(pontoDestribuidoParaUmAtributo <= totalDePontos && pontoDestribuidoParaUmAtributo >= 0)
                {
                    jogador.setDestrezaDoJogador(pontoDestribuidoParaUmAtributo + jogador.getDestrezaDoJogador());
                    break;
                }
            }
            
            totalDePontos -= pontoDestribuidoParaUmAtributo;
        }
        
        vida += jogador.getConstituicaoDoJogador();
        jogador.setPontosDeVidaDoJogador(vida);
        jogador.setVidaMaximaDoJogador(vida);
                
        System.out.println("\nPontos de vida: " + jogador.getVidaMaximaDoJogador());
        System.out.printf("Forca: %.0f\n", jogador.getForcaDoJogador());
        System.out.printf("Constituicao: %.0f\n", jogador.getConstituicaoDoJogador());
        System.out.println("Agilidade: " + jogador.getAgilidadeDoJogador());
        System.out.println("Destreza: " + jogador.getDestrezaDoJogador());
        System.out.println("Pocoes: 3");
    }
    
                  
  public static void escolhaDeArma(Weapon armaDoJogador, Weapon armaGenerica1, Weapon armaGenerica2, Weapon armaGenerica3)
    {
        Scanner input = new Scanner(System.in);
        
        int escolhaDeArma;
        
     OUTER:
     while (true) {
         System.out.println("\nEscolha uma arma\n");
         System.out.println("1-" + armaGenerica1.getNomeDaArma() + " 2-" + armaGenerica2.getNomeDaArma() + " 3-" + armaGenerica3.getNomeDaArma());
         escolhaDeArma = input.nextInt();
         switch (escolhaDeArma) {
             case 1 -> {
                 armaDoJogador.setNomeDaArma(armaGenerica1.getNomeDaArma());
                 if(" Broken Straight Sword (Leve)".equals(armaDoJogador.getNomeDaArma()))
                 {
                     System.out.println("\nVoce tem coragem");
                 }
                 else
                 {
                     System.out.println("\n" + armaGenerica1.getNomeDaArma() + " selecionada.");
                 }armaDoJogador.setCategoriaDaArma(armaGenerica1.getCategoriaDaArma());
                 armaDoJogador.setConstanteDeDano(armaGenerica1.getConstanteDeDano());
                 break OUTER;
                }
             case 2 -> {
                 armaDoJogador.setNomeDaArma(armaGenerica2.getNomeDaArma());
                 System.out.println("\n" + armaGenerica2.getNomeDaArma() + " selecionada.");
                 armaDoJogador.setCategoriaDaArma(armaGenerica2.getCategoriaDaArma());
                 armaDoJogador.setConstanteDeDano(armaGenerica2.getConstanteDeDano());
                 if("Moonlight Greatsword (Pesada)".equals(armaDoJogador.getNomeDaArma()))
                 {
                     System.out.println("Habilidade especial: Frostbyte (causa dano adicional após atacar quatro vezes (+7) e diminui o dano do oponente por um turno (-15)");
                 }break OUTER;
                }
             case 3 -> {
                 armaDoJogador.setNomeDaArma(armaGenerica3.getNomeDaArma());
                 System.out.println("\n" + armaGenerica3.getNomeDaArma() + " selecionada.");
                 if("uchigatana (Leve)".equals(armaDoJogador.getNomeDaArma()))
                 {
                     System.out.println("Habilidade especial: Sangramento (causa dano adicional após atacar tres vezes)");
                 }armaDoJogador.setCategoriaDaArma(armaGenerica3.getCategoriaDaArma());
                 armaDoJogador.setConstanteDeDano(armaGenerica3.getConstanteDeDano());
                 break OUTER;
                }
             default -> {
                }
         }
     }
    }
  
    public static void escolhaDeArmadura(Armor armaduraDoJogador, Armor armaduraGenerica1, Armor armaduraGenerica2, Armor armaduraGenerica3, Player jogador)
    {
        Scanner ler = new Scanner(System.in);
        
        int escolhaDeArmadura;
        
        while(true)
        {
            System.out.println("\nEscolha uma armadura\n");
            System.out.println("1-" + armaduraGenerica1.getNomeDaArmadura() + " 2-" + armaduraGenerica2.getNomeDaArmadura() + " 3-" + armaduraGenerica3.getNomeDaArmadura());
            escolhaDeArmadura = ler.nextInt();
        
            if(escolhaDeArmadura == 1)
            {
                armaduraDoJogador.setNomeDaArmadura(armaduraGenerica1.getNomeDaArmadura());
                if(armaduraDoJogador.getNomeDaArmadura() == "Sem Armadura")
                {
                    System.out.println("\nSem Armadura?");
                }
                else if(armaduraDoJogador.getNomeDaArmadura() == "Catarina's Set")
                {
                    System.out.println("\n" + armaduraGenerica1.getNomeDaArmadura() + " selecionada.");
                    System.out.println("\nSeu corpo eh envolto em raios");
                    System.out.println("\nHabilidade Especial: 40% de chance de stunar quem o atacar");
                }    
                
                armaduraDoJogador.setConstanteDeDefesa(armaduraGenerica1.getConstanteDeDefesa());
                break;
            }
            else if(escolhaDeArmadura == 2)
            {   
                armaduraDoJogador.setNomeDaArmadura(armaduraGenerica2.getNomeDaArmadura());
                System.out.println("\n" + armaduraGenerica2.getNomeDaArmadura() + " selecionada.");
                
                if(armaduraDoJogador.getNomeDaArmadura() == "Onstein's Set")
                {
                    System.out.println("\nBoa defesa, porem pesada (perdeu 1 de agilidade) e fica fadigado a cada 5 turnos");
                     
                    jogador.setAgilidadeDoJogador(jogador.getAgilidadeDoJogador() - 1);
                }
                
                armaduraDoJogador.setConstanteDeDefesa(armaduraGenerica2.getConstanteDeDefesa());
                break;
            }
            else if(escolhaDeArmadura == 3)
            {
                armaduraDoJogador.setNomeDaArmadura(armaduraGenerica3.getNomeDaArmadura());
                System.out.println("\n" + armaduraGenerica3.getNomeDaArmadura() + " selecionada.");
                
                if(armaduraDoJogador.getNomeDaArmadura() == "Berserk Set")
                {
                    System.out.println("\nOtima defesa, porem bem pesada (perdeu 4 de agilidade) e perde 2 de vida a cada turno");

                    jogador.setAgilidadeDoJogador(jogador.getAgilidadeDoJogador() - 4);
                }
                
                armaduraDoJogador.setConstanteDeDefesa(armaduraGenerica3.getConstanteDeDefesa());
                break;
            }
            else
            {
                
            }
        }
    }
  
  public static int combate(Enemy adversarioGenerico, Player jogador, Weapon arma, Armor armadura)
    {
        Scanner ler = new Scanner(System.in);
        Random gerador = new Random();
        
        Potion pocoesDoJogador = new Potion();
        Potion pocoesDoAdversario = new Potion();
        pocoesDoJogador.setQuantidadeDePocoes(3);
        pocoesDoAdversario.setQuantidadeDePocoes(3);
        
        double armaduraMaximaDoJogador = armadura.getValorDeArmadura();
        int defesaMaximaDoAdversario = adversarioGenerico.getDefesaDoAdversario();
        int escolhaDeAcaoDoJogador;
        int escolhaDeAcaoDoAdversario;
        double dano;
        int vida = 0;
        int cura = 0;
        int pocao;
        int stun = 0;
        boolean adversario_stun = false;
        int sangramento = 0;
        int frostbyte = 0;
        int fadiga = 0;
        boolean adversario_frostbyte = false;
        
        while(true) //while do combate
        {   
            if(adversarioGenerico.getNomeDoAdversario() == "Gwyn Lord of Cinder")
            {
              System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠀⠀⠀⢹⡿⣿⠳⡀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⣯⣿⠿⣷⣤⡀⠀⢹⣧⣈⣷⡽⡄⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣷⣿⣯⡰⢿⡿⢿⣷⡤⠤⠤⢿⣿⣿⣿⣞⣆⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⢾⡧⣿⣶⣟⡁⠀⠀⢡⣨⡟⢿⣄⣀⣀⢹⣿⣿⣿⣞⣦⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡶⣯⡽⠁⢸⡅⠘⣦⡙⠻⢯⣭⣿⣽⠃⠈⣿⠳⠤⡋⠰⣿⠛⣿⣾⣧⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⡿⢸⣧⡀⠈⢿⣦⡘⢿⣦⡈⠙⣿⣿⣞⣁⣿⣀⣀⣹⢧⣼⡿⠽⢿⣧⢳⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⠃⢸⣿⣿⣾⡈⠙⠿⣷⣭⣛⠓⠛⠁⡼⣿⢿⢿⣿⣿⣿⣿⣷⡇⣼⣿⡄⢣⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⢠⣶⣿⣿⣿⠉⣆⣿⠃⣹⣿⣿⣷⣆⠄⠀⠈⠀⣠⢞⣠⣿⡟⠀⠉⣿⣿⣿⣿⣷⣾⣿⣷⠘⣧⠀");
        System.out.println("⠀⠀⠀⠀⠀⣼⡿⣮⣟⢻⣿⣦⣿⣯⣷⣿⣿⣿⣿⣿⣿⣿⠷⠛⠁⣼⣿⣿⠁⠀⠀⢿⣿⣿⣿⣙⣷⢿⡿⣇⢿⡄");
        System.out.println("⠀⠀⠀⠀⠀⣿⠖⢻⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⠻⠿⠷⣶⣾⣿⣿⠏⠀⠀⠀⠘⠻⢿⣿⣯⣹⣿⡿⢿⡾⢳");
        System.out.println("⣀⡀⠀⠀⠀⡿⠀⠸⡄⣼⠁⠀⢠⣿⣿⣿⣝⣿⣿⣿⣷⣴⣾⣿⣾⣿⣿⣿⣦⡀⠀⠀⠀⠑⢖⠻⢿⣿⠁⣸⠇⢸");
        System.out.println("⠙⢿⣶⡀⠀⠹⡄⠀⣿⠃⠀⠀⢸⣿⣿⣿⢿⡟⠢⢄⣿⣿⣿⣿⣿⠛⣼⣿⠽⠿⣦⡀⠀⠀⠀⠁⠀⣽⣿⡟⣰⣿");
        System.out.println("⠀⠀⠈⠷⣤⣸⡗⢰⣇⠀⠀⠀⢸⣿⡟⣿⠀⠓⠶⠿⠏⣼⣿⣿⠍⣾⠁⠀⠀⠀⠈⣧⣄⡀⠀⠀⠀⢸⣿⡶⠃");
        System.out.println("⠀⠀⠀⠀⠘⢻⡷⢊⣻⣆⠀⠀⢸⣿⣿⡏⠀⠀⠀⢠⣼⣇⣻⣿⣿⣿⡇⠀⠀⠀⠀⣸⣿⢿⠁⠀⠀⠀⠈⡟⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠸⣄⣼⣿⣿⡀⠀⠀⢿⣿⣷⡀⠀⠀⣾⣿⡏⠀⣿⣿⣿⣷⠀⠀⠀⠀⣸⣿⢿⠁⠀⠀⠀⠈⡟⠀⠀");
            }
            System.out.println("\n" + adversarioGenerico.getNomeDoAdversario());
            System.out.println("Vida: " + adversarioGenerico.getPontosDeVidaDoAdversario() + "/" + adversarioGenerico.getVidaMaximaDoAdversario() + "\nPocoes: " + pocoesDoAdversario.getQuantidadeDePocoes() + "\nArmadura: " + adversarioGenerico.getDefesaDoAdversario() + "\nAgilidade: " + adversarioGenerico.getAgilidadeDoAdversario());
            System.out.println("\n" + jogador.getNomeDoJogador());
            System.out.println("Vida: " + jogador.getPontosDeVidaDoJogador() + "/" + jogador.getVidaMaximaDoJogador() + "\nPocoes: " + pocoesDoJogador.getQuantidadeDePocoes() + "\nArmadura: " + (int) armadura.getValorDeArmadura() + "\nAgilidade: " + jogador.getAgilidadeDoJogador());
            System.out.println("\n1- Atacar  2- Defender  3- Usar pocao");
            
            escolhaDeAcaoDoJogador = ler.nextInt();
            if(armadura.getNomeDaArmadura() == "Berserk Set")
            {   
                if(jogador.getPontosDeVidaDoJogador() > 2)
                {
                    jogador.setPontosDeVidaDoJogador(jogador.getPontosDeVidaDoJogador() - 2);
                }
            }
            else if(armadura.getNomeDaArmadura() == "ornstein's Set")
            {
                fadiga++;
            }
            if(escolhaDeAcaoDoJogador == 4)
            {
                System.out.println("\nCheat de aumentar vida\n");
                vida = 999;
                jogador.setPontosDeVidaDoJogador(vida);
                jogador.setVidaMaximaDoJogador(vida);
            }
            if(escolhaDeAcaoDoJogador == 5)
            {
                System.out.println("\nCheat de aumentar pocao\n");
                pocoesDoJogador.setQuantidadeDePocoes(99);
            }
            else if(escolhaDeAcaoDoJogador == 6)
            {
                System.out.println("\n" + jogador.getNomeDoJogador() + " venceu!!!\n");
                return 1; 
            }
            else if(escolhaDeAcaoDoJogador == 7)
            {
                break;
            }
            if(jogador.getAgilidadeDoJogador() > adversarioGenerico.getAgilidadeDoAdversario())
            {
                armadura.setValorDeArmadura(armaduraMaximaDoJogador);
                if(fadiga > 4)
                {
                    fadiga = 0;
                    System.out.println(jogador.getNomeDoJogador() + " esta afetado pela fadiga e nao pode se mover nesse turno!");
                }
                else
                {
                    if(escolhaDeAcaoDoJogador == 1)
                    {   
                        System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu atacar!");
                        if(arma.getCategoriaDaArma() == 1)
                        {
                            dano = (int) (arma.getConstanteDeDano() + gerador.nextInt(8) + 1 + gerador.nextInt(8) + 1 + gerador.nextInt(6) + 1 + jogador.getDestrezaDoJogador() - adversarioGenerico.getDefesaDoAdversario());

                            if(arma.getNomeDaArma() == "Uchigatana (Leve)")
                            {
                                sangramento++;
                                if(sangramento >= 3)
                                {
                                    dano += 10;
                                    sangramento = 0;
                                    System.out.println("O adversario sofreu +10 de dano por Sangramento!");
                                }
                            }    
                        }
                        else
                        {
                            dano = (int) (arma.getConstanteDeDano() + gerador.nextInt(12) + 1 + 1.5*jogador.getForcaDoJogador() - adversarioGenerico.getDefesaDoAdversario());
                            if(arma.getNomeDaArma() == "Moonlight Greatsword (Pesada)")
                            {
                                frostbyte++;
                                if(frostbyte >= 4)
                                {
                                    dano += 7;
                                    frostbyte = 0;
                                    adversario_frostbyte = true;
                                    System.out.println("O adversario sofreu +7 de dano por frostbyte e seu dano foi reduzido para o proximo turno!");
                                }
                            }
                        }
                        if(dano <= 0)
                        {
                            dano = 1;
                        }
                        vida = adversarioGenerico.getPontosDeVidaDoAdversario();

                        vida -= dano;
                        adversarioGenerico.setPontosDeVidaDoAdversario(vida);
                        System.out.println("Dano: " + dano);

                        if(adversarioGenerico.getPontosDeVidaDoAdversario() <= 0)
                        {
                            System.out.println("\n" + jogador.getNomeDoJogador() + " venceu!!!\n");
                            return 1;
                        }
                    }
                    else if(escolhaDeAcaoDoJogador == 2)
                    {
                        System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu defender! \nSua Defesa dobrou!");
                        armadura.setValorDeArmadura(2*armadura.getValorDeArmadura());
                    }
                    else if(escolhaDeAcaoDoJogador == 3)
                    {
                        if(pocoesDoJogador.getQuantidadeDePocoes() <= 0)
                        {
                            System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu usar uma pocao, mas elas ja acabaram...");
                        }
                        else
                        {    
                            System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu usar uma pocao!");

                            vida = jogador.getPontosDeVidaDoJogador();
                            cura = pocoesDoJogador.getValorDeCura();
                            pocao = pocoesDoJogador.getQuantidadeDePocoes();

                            vida += cura;
                            pocao--;

                            pocoesDoJogador.setQuantidadeDePocoes(pocao);

                            if(vida > jogador.getVidaMaximaDoJogador())
                            {
                                cura = jogador.getVidaMaximaDoJogador() - jogador.getPontosDeVidaDoJogador();
                                System.out.println("Cura: " + cura);
                                jogador.setPontosDeVidaDoJogador(jogador.getVidaMaximaDoJogador());
                            }
                            else
                            {
                                System.out.println("Cura: " + cura);
                                jogador.setPontosDeVidaDoJogador(vida);
                            }
                        }
                    }
                }   
                escolhaDeAcaoDoAdversario = gerador.nextInt(6);
                       
                adversarioGenerico.setDefesaDoAdversario(defesaMaximaDoAdversario);
                if(adversario_stun == true)
                {
                    System.out.println("\nO adversario esta stunado! \nNao consegue se mover!");
                    adversario_stun = false;
                }
                else
                {
                    if(escolhaDeAcaoDoAdversario == 0 || escolhaDeAcaoDoAdversario == 1 || escolhaDeAcaoDoAdversario == 2)
                    {
                        System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu atacar!");

                        dano = (int) (adversarioGenerico.getDanoDoAdversario() - armadura.getValorDeArmadura());
                        if(adversarioGenerico.getNomeDoAdversario() == "Kalameet" && armadura.getNomeDaArmadura() == "Ornstein's Set")
                        {
                            dano = dano - 5;
                        }
                        if(adversario_frostbyte == true)
                        {
                            dano = dano - 15;
                            adversario_frostbyte = false;
                            System.out.println("Dano de " + adversarioGenerico.getNomeDoAdversario() + " reduzido para esse ataque! (-15)");
                        }
                        if(dano <= 0)
                        {
                            dano = 1;
                        }
                        
                        vida = jogador.getPontosDeVidaDoJogador();

                        vida -= dano;
                        jogador.setPontosDeVidaDoJogador(vida);
                        System.out.println("Dano: " + dano);

                        if(jogador.getPontosDeVidaDoJogador() <= 0)
                        {
                            
                            System.out.println("\nVoce Morreu...\n");
                            return 0;
                        }

                        if(armadura.getNomeDaArmadura() == "Catarina's Set")
                        {
                            stun = gerador.nextInt(5) + 1;
                            if(stun == 1 || stun == 2)
                            {
                                System.out.println("\nO adversario foi stunado pelos raios!!!");
                                adversario_stun = true;
                            }
                        }    
                    }
                    else if(escolhaDeAcaoDoAdversario == 3 || escolhaDeAcaoDoAdversario == 4)
                    {
                        System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu defender! \nSua Defesa dobrou!");
                        if(adversario_frostbyte == true)
                        {
                            adversario_frostbyte = false;
                        }

                        adversarioGenerico.setDefesaDoAdversario(2*adversarioGenerico.getDefesaDoAdversario());
                    }
                    else if(escolhaDeAcaoDoAdversario == 5)
                    {
                        if(adversario_frostbyte == true)
                        {
                            adversario_frostbyte = false;
                        }
                        if(pocoesDoAdversario.getQuantidadeDePocoes() <= 0)
                        {
                            System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu usar uma pocao, mas elas ja acabaram...");
                        }
                        else
                        {    
                            System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu usar uma pocao!");
                        
                            vida = adversarioGenerico.getPontosDeVidaDoAdversario();
                            cura = pocoesDoAdversario.getValorDeCura();
                            pocao = pocoesDoAdversario.getQuantidadeDePocoes();

                            vida += cura;
                            pocao--;

                            pocoesDoAdversario.setQuantidadeDePocoes(pocao);

                            if(vida > adversarioGenerico.getVidaMaximaDoAdversario())
                            {
                                cura = adversarioGenerico.getVidaMaximaDoAdversario() - adversarioGenerico.getPontosDeVidaDoAdversario();
                                System.out.println("Cura: " + cura);
                                adversarioGenerico.setPontosDeVidaDoAdversario(adversarioGenerico.getVidaMaximaDoAdversario());
                            }
                            else
                            {
                                System.out.println("Cura: " + cura);
                                adversarioGenerico.setPontosDeVidaDoAdversario(vida);
                            }
                        }
                    }
                }//if-else stun
            }      
            else if(adversarioGenerico.getAgilidadeDoAdversario() > jogador.getAgilidadeDoJogador())
            {
                escolhaDeAcaoDoAdversario = gerador.nextInt(6);
                
                adversarioGenerico.setDefesaDoAdversario(defesaMaximaDoAdversario);
                if(adversario_stun == true)
                {
                    System.out.println("\nO adversario esta stunado! \nNao consegue se mover!");
                    adversario_stun = false;
                }
                else
                {
                    if(escolhaDeAcaoDoAdversario == 0 || escolhaDeAcaoDoAdversario == 1 || escolhaDeAcaoDoAdversario == 2)
                    {
                        System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu atacar!");

                        dano = (int) (adversarioGenerico.getDanoDoAdversario() - armadura.getValorDeArmadura());
                        if(adversarioGenerico.getNomeDoAdversario() == "Kalameet" && armadura.getNomeDaArmadura() == "Armadura Matadora de Dragao")
                        {
                            dano = dano - 5;
                        }
                        if(adversario_frostbyte == true)
                        {
                            dano = dano - 15;
                            adversario_frostbyte = false;
                            System.out.println("Dano de " + adversarioGenerico.getNomeDoAdversario() + " reduzido para esse ataque! (-15)");
                        }
                        if(dano <= 0)
                        {
                            dano = 1;
                        }
                        vida = jogador.getPontosDeVidaDoJogador();

                        vida -= dano;
                        jogador.setPontosDeVidaDoJogador(vida);
                        System.out.println("Dano: " + dano);

                        if(jogador.getPontosDeVidaDoJogador() <= 0)
                        {
                            
                            System.out.println("\nVoce Morreu\n");
                            return 0;
                        }

                        if(armadura.getNomeDaArmadura() == "Catarina's Set")
                        {
                            stun = gerador.nextInt(5) + 1;
                            if(stun == 1 || stun == 2)
                            {
                                System.out.println("\nO adversario foi stunado pelos raios!!!");
                                adversario_stun = true;
                            }
                        }
                    }
                    else if(escolhaDeAcaoDoAdversario == 3 || escolhaDeAcaoDoAdversario == 4)
                    {
                        System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu defender! \nSua Defesa dobrou!");

                        adversarioGenerico.setDefesaDoAdversario(2*adversarioGenerico.getDefesaDoAdversario());
                        if(adversario_frostbyte == true)
                        {
                            adversario_frostbyte = false;
                        }
                    }
                    else if(escolhaDeAcaoDoAdversario == 5)
                    {
                        if(adversario_frostbyte == true)
                        {
                            adversario_frostbyte = false;
                        }
                        if(pocoesDoAdversario.getQuantidadeDePocoes() <= 0)
                        {
                            System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu usar uma pocao, mas elas ja acabaram...");
                            
                        }
                        else
                        {    
                            System.out.println("\n" + adversarioGenerico.getNomeDoAdversario() + " escolheu usar uma pocao!");
                        
                            vida = adversarioGenerico.getPontosDeVidaDoAdversario();
                            cura = pocoesDoAdversario.getValorDeCura();
                            pocao = pocoesDoAdversario.getQuantidadeDePocoes();

                            vida += cura;
                            pocao--;

                            pocoesDoAdversario.setQuantidadeDePocoes(pocao);

                            if(vida > adversarioGenerico.getVidaMaximaDoAdversario())
                            {
                                cura = adversarioGenerico.getVidaMaximaDoAdversario() - adversarioGenerico.getPontosDeVidaDoAdversario();
                                System.out.println("Cura: " + cura);
                                adversarioGenerico.setPontosDeVidaDoAdversario(adversarioGenerico.getVidaMaximaDoAdversario());
                            }
                            else
                            {
                                System.out.println("Cura: " + cura);
                                adversarioGenerico.setPontosDeVidaDoAdversario(vida);
                            }
                        }
                    }
                }//if-else stun
                
                armadura.setValorDeArmadura(armaduraMaximaDoJogador);
                if(fadiga > 4)
                {
                    fadiga = 0;
                    System.out.println(jogador.getNomeDoJogador() + " esta afetado pela fadiga e nao pode se mover nesse turno!");
                }
                else
                {
                    switch (escolhaDeAcaoDoJogador) {
                        case 1:
                            System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu atacar!");
                            if(arma.getCategoriaDaArma() == 1)
                            {
                                dano = (int) (arma.getConstanteDeDano() + gerador.nextInt(6) + 1 + gerador.nextInt(6) + 1 + gerador.nextInt(4) + 1 + jogador.getDestrezaDoJogador() - adversarioGenerico.getDefesaDoAdversario());
                                if(arma.getNomeDaArma() == "Uchigatana (Leve)")
                                {
                                    sangramento++;
                                    if(sangramento >= 3)
                                    {
                                        dano += 10;
                                        sangramento = 0;
                                        System.out.println("O adversario sofreu +10 de dano por Sangramento!");
                                    }
                                }
                            }
                            else
                            {
                                dano = (int) (arma.getConstanteDeDano() + gerador.nextInt(12) + 1 + 1.5*jogador.getForcaDoJogador() - adversarioGenerico.getDefesaDoAdversario());
                                if(arma.getNomeDaArma() == "Moonlight Greatsword (Pesada)")
                                {
                                    frostbyte++;
                                    if(frostbyte >= 4)
                                    {
                                        dano += 7;
                                        frostbyte = 0;
                                        adversario_frostbyte = true;
                                        System.out.println("O adversario sofreu +7 de dano por frostbyte e seu dano foi reduzido para o proximo turno!");
                                    }
                                }
                            }   if(dano <= 0)
                            {
                                dano = 1;
                            }   vida = adversarioGenerico.getPontosDeVidaDoAdversario();
                            vida -= dano;
                            adversarioGenerico.setPontosDeVidaDoAdversario(vida);
                            System.out.println("Dano: " + dano);
                            if(adversarioGenerico.getPontosDeVidaDoAdversario() <= 0)
                            {
                                System.out.println("\n" + jogador.getNomeDoJogador() + " venceu!!!\n");
                                return 1;
                            }   break;
                        case 2:
                            System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu defender! \nSua Defesa dobrou!");
                            armadura.setValorDeArmadura(2*armadura.getValorDeArmadura());
                            break;
                        case 3:
                            if(pocoesDoJogador.getQuantidadeDePocoes() <= 0)
                            {
                                System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu usar uma pocao, mas elas ja acabaram...");
                            }
                            else
                            {
                                System.out.println("\n" + jogador.getNomeDoJogador() + " escolheu usar uma pocao!");
                                
                                vida = jogador.getPontosDeVidaDoJogador();
                                cura = pocoesDoJogador.getValorDeCura();
                                pocao = pocoesDoJogador.getQuantidadeDePocoes();
                                
                                vida += cura;
                                pocao--;
                                
                                pocoesDoJogador.setQuantidadeDePocoes(pocao);
                                
                                if(vida > jogador.getVidaMaximaDoJogador())
                                {
                                    cura = jogador.getVidaMaximaDoJogador() - jogador.getPontosDeVidaDoJogador();
                                    System.out.println("Cura: " + cura);
                                    jogador.setPontosDeVidaDoJogador(jogador.getVidaMaximaDoJogador());
                                }
                                else
                                {
                                    System.out.println("Cura: " + cura);
                                    jogador.setPontosDeVidaDoJogador(vida);
                                }
                            }   break;
                        default:
                            break;
                    }
                }
            } //if-else agilidade        
            
        } //while do combate
        
        return 0;
    }
    
   public static void gameOver()
    {
         System.out.println(" __     __               __  __                           ");
        System.out.println(" \\ \\   / /__   ___ ___  |  \\/  | ___  _ __ _ __ ___ _   _ ");
        System.out.println("  \\ \\ / / _ \\ / __/ _ \\ | |\\/| |/ _ \\| '__| '__/ _ \\ | | |");
        System.out.println("   \\ V / (_) | (_|  __/ | |  | | (_) | |  | | |  __/ |_| |");
        System.out.println("    \\_/ \\___/ \\___\\___| |_|  |_|\\___/|_|  |_|  \\___|\\__,_|");
    }
    static void victory(){
        
        System.out.println("Voce cumpriu a sua jornada, Hollow, agora voce guiara a humanidade em sua proxima era");
        
        
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣯⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⢺⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡏⣧⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⢶⣿⣋⣟⠭⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⣭⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡏⢮⣳⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡿⣦⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⠢⣽⣅⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡆⢤⣿⡇⠀⠀⠀⠀⣸⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢷⠸⣞⡇⠀⠀⠀⠀⡏⢧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡄⣿⣷⠀⠀⠀⠀⢻⡈⢣⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣇⢸⣿⡆⠀⠀⠀⠀⢳⣬⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡈⣿⣧⠀⠀⢠⡄⣸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡇⢹⣿⡀⠀⢸⢧⠟⢹⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠸⣿⡇⣠⠋⢾⣾⢸⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡇⢹⣿⡇⡏⣧⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠸⣿⡇⠃⣠⢴⣶⣿⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠃⢀⣴⡆⠀⢹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡖⠀⠀⠸⣿⣶⣿⣷⡏⢰⡿⢿⠏⣸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⠀⣴⢋⣿⣿⣿⠇⡟⠁⣏⠀⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⡞⣏⢦⠇⢸⡿⢿⠋⢀⣤⣀⡘⢦⡟⢸⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠃⢀⣴⡆⠀⠀⠈⣹⣿⣷⡏⢰⡿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⢠⠜⢁⡴⠋⡀⠙⢄⠀⣰⣿⣿⣖⣸⣨⣿⠿⠛⣻⣿⣶⣾⣾⠇⠀⠻⣄⠀⠀");
        System.out.println("⠀⣠⣴⣺⢿⣿⣿⡛⠛⠿⠿⣯⣷⡲⣶⣟⣻⡀⠀⣠⣿⣿⣖⣸⣨⣿⠿⠛⣻⣿⣶⣾⣾⠇⠀⠻⣄");
        System.out.println("⢺⣥⢿⠾⠿⠿⠿⡿⠚⢋⣠⠯⣿⢉⢉⠻⠾⠛⢿⣿⠻⠿⢛⢋⣤⣯⣭⠽⠶⣾⣻⢿⣻⢿⠶⢛⣻⣄");
    
    }
  
}