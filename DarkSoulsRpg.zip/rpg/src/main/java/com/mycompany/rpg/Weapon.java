package com.mycompany.rpg;


public class Weapon {
    
    private String WeaponName;
    private int WeaponCategory;
    private int ConstDamage;
    
    
    public void setNomeDaArma(String WeaponName)
    {
        this.WeaponName = WeaponName;
    }
    
    public String getNomeDaArma()
    {
        return this.WeaponName;
    }
    
    public void setCategoriaDaArma(int WeaponCategory)
    {
        this.WeaponCategory = WeaponCategory;
    }
    
    public int getCategoriaDaArma()
    {
        return this.WeaponCategory;
    }
    
    public void setConstanteDeDano(int ConstDamage)
    {
        this.ConstDamage = ConstDamage;
    }
    
    public int getConstanteDeDano()
    {
        return this.ConstDamage;
    }
    
}
