
package com.mycompany.rpg;

import java.util.Random;


public class Potion {
    
    
    
    Random gerador = new Random();
    
    private int potionAmount;
    private int healingValue;
    private int healingRollValue;
    
    public void setQuantidadeDePocoes(int potionAmount)
    {
        this.potionAmount = potionAmount;
    }
    
    public int getQuantidadeDePocoes()
    {
        return this.potionAmount;
    }
    
    public int getValorDeCura()
    {
        healingValue = 0;
        for (int i = 0; i < 3; i++)
        {
            healingRollValue = gerador.nextInt(6) + 1;
            healingValue += healingRollValue;
        }
        return healingValue;
    }
    
    
    
}
