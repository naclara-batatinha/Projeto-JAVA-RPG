
package com.mycompany.rpg;


public class Enemy {
    
    
    private String MonsterName;
    private int MonsterHP = 0;
    private int MonsterMaxHP;
    private int MonsterDamage = 0;
    private int MonsterDef = 0;
    private double MonsterAgility = 0;
    
    public void setNomeDoAdversario(String MonsterName)
    {
        this.MonsterName = MonsterName;
    }
    
    public String getNomeDoAdversario()
    {
        return this.MonsterName;
    }
    
    public void setPontosDeVidaDoAdversario(int MonsterHP)
    {
        this.MonsterHP = MonsterHP;
    }
    
    public int getPontosDeVidaDoAdversario()
    {
        return this.MonsterHP;
    }
    
    public void setVidaMaximaDoAdversario(int MonsterMaxHP)
    {
        this.MonsterMaxHP = MonsterMaxHP;
    }
    
    public int getVidaMaximaDoAdversario()
    {
        return MonsterMaxHP;
    }
    
    public void setDanoDoAdversario(int MonsterDamage)
    {
        this.MonsterDamage = MonsterDamage;
    }
    
    public int getDanoDoAdversario()
    {
        return this.MonsterDamage;
    }
    
    public void setDefesaDoAdversario(int constituicaoDoAdversario)
    {
        this.MonsterDef = constituicaoDoAdversario;
    }
    
    public int getDefesaDoAdversario()
    {
        return this.MonsterDef;
    }
    
    public void setAgilidadeDoAdversario(double MonsterAgility)
    {
        this.MonsterAgility = MonsterAgility;
    }
    
    public double getAgilidadeDoAdversario()
    {
        return this.MonsterAgility;
    }
 
}
