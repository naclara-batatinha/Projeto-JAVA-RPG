
package com.mycompany.rpg;

public class Armor {
    
    
    private String ArmorName;
    private double ArmorValue;
    private double ConstDef;
    
    public void setNomeDaArmadura(String ArmorName)
    {
        this.ArmorName = ArmorName;
    }
    
    public String getNomeDaArmadura()
    {
        return this.ArmorName;
    }
    
    public void setConstanteDeDefesa(double ConstDef)
    {
        this.ConstDef = ConstDef;
    }
    
    public double getConstanteDeDefesa()
    {
        return this.ConstDef;
    }
    
    public void setValorDeArmadura(double valorDeArmadura)
    {
        this.ArmorValue = ArmorValue;
    }
    
    public double getValorDeArmadura()
    {
        return this.ArmorValue;
    }
  
}
