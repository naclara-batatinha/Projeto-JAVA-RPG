package com.mycompany.rpg;


public class Player {
     
    
    private String PlayerName;
    private int PlayerPV= 0;
    private double PlayerStrenght = 0;
    private double PlayerConst = 0;
    private int PlayerAgility = 0;
    private int PlayerDex = 0;
    private int MaxHP = 0;
    
   public void setNomeDoJogador(String PlayerName)
    {
        this.PlayerName = PlayerName;
    }
    
    public String getNomeDoJogador()
    {
        return this.PlayerName;
    }

    public void setVidaMaximaDoJogador(int MaxHP)
    {
        this.MaxHP = MaxHP;
    }
    
    public int getVidaMaximaDoJogador()
    {
        return this.MaxHP;
    }
  
    public void setPontosDeVidaDoJogador(int PlayerPV)
    {
        this.PlayerPV = PlayerPV;
    }
    
    public int getPontosDeVidaDoJogador()
    {
        return this.PlayerPV;
    }
    
    public void setForcaDoJogador(double PlayerStrenght)
    {
        this.PlayerStrenght = PlayerStrenght;
    }
    
    public double getForcaDoJogador()
    {
        return this.PlayerStrenght;
    }
    
    public void setConstituicaoDoJogador(double PlayerConst)
    {
        this.PlayerConst = PlayerConst;
    }
    
    public double getConstituicaoDoJogador()
    {
        return this.PlayerConst;
    }
    
    public void setAgilidadeDoJogador(int PlayerAgility)
    {
        this.PlayerAgility = PlayerAgility;
    }
    
    public int getAgilidadeDoJogador()
    {
        return this.PlayerAgility;
    }
    
    public void setDestrezaDoJogador(int PlayerDex)
    {
        this.PlayerDex = PlayerDex;
    }
    
    public int getDestrezaDoJogador()
    {
        return this.PlayerDex;
    }
}
     
     
    

